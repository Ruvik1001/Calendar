Calendar is an open source application designed to facilitate the allocation of time. It uses a nice graphic design, the functionality of displaying the current day and adding your own holidays.

To install, clone the repository using:
'git clone https://github.com/Ruvik1001/Calendar.git

Then, to start, refer to Calendar.py 

Enjoy it!
