import Lib.MyClaendar

def create():
    """
    create object of MyCalendar class and start work it
    """
    test = Lib.MyClaendar.MyCalendar(icopath='../resources/icon.ico')
    test.start()
